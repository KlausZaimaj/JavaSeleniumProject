package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.AccountCreationPage;
import pages.HomePage;
import utils.WebDriverSetup;

public class CreateAccountTest extends WebDriverSetup {

    @Test
    public void testCreateAccount() {
        // Step 1: Navigate to the homepage
        driver.get("https://magento.softwaretestingboard.com/");
        HomePage homePage = new HomePage(driver);

        // Step 2: Click Create an Account link
        homePage.clickCreateAccount();

        // Step 3: Verify the title of the account creation page
        AccountCreationPage accountCreationPage = new AccountCreationPage(driver);
        Assert.assertEquals(driver.getTitle(), "Create New Customer Account");

        // Step 4: Fill in the form fields
        accountCreationPage.fillForm("Johnny", "Smith", "johnny.smith@gmail.com", "Password123!");

        // Step 5: Click Create an Account button
        accountCreationPage.clickCreateAccountButton();

        // Step 6: Verify the success message
        Assert.assertTrue(accountCreationPage.isSuccessMessageDisplayed(), "Account creation failed!");

        // Step 7: Sign out
        accountCreationPage.signOut();
    }
}