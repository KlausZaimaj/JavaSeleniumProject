package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;
import pages.WishListPage;
import pages.WomenPage;
import utils.WebDriverSetup;

public class WishListTest extends WebDriverSetup {

    @Test
    public void testWishList() {
        // Precondition: Sign in and navigate to Women > Tops > Jackets
        driver.get("https://magento.softwaretestingboard.com/");
        HomePage homePage = new HomePage(driver);
        homePage.clickSignIn();
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("johnny.smith@gmail.com", "Password123!");
        homePage.clickWomenMenu();
        WomenPage womenPage = new WomenPage(driver);
        womenPage.selectJacketsCategory();

        // Step 1: Remove price filter (if applied)
        womenPage.removePriceFilter();

        // Step 2: Verify the number of items displayed increases
        int initialProductCount = womenPage.getNumberOfProducts();
        Assert.assertTrue(womenPage.getNumberOfProducts() > initialProductCount, "Product count did not increase after removing filters!");

        // Step 3: Add the first two items to the wishlist
        WishListPage wishListPage = new WishListPage(driver);
        wishListPage.addFirstTwoItemsToWishList();

        // Step 4: Verify the success message
        Assert.assertTrue(wishListPage.isSuccessMessageDisplayed(), "Items not added to wishlist!");

        // Step 5: Verify the correct number of items in the wishlist
        wishListPage.navigateToWishList();
        Assert.assertEquals(wishListPage.getNumberOfWishListItems(), 2, "Incorrect number of items in the wishlist!");
    }
}
