package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;
import pages.WomenPage;
import utils.WebDriverSetup;

public class PageFiltersTest extends WebDriverSetup {

    @Test
    public void testPageFilters() {
        // Precondition: Sign in (use SignInTest logic if needed)
        driver.get("https://magento.softwaretestingboard.com/");
        HomePage homePage = new HomePage(driver);
        homePage.clickSignIn();
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("johnny.smith@gmail.com", "Password123!");

        // Step 1: Navigate to Women > Tops > Jackets
        homePage.clickWomenMenu();
        WomenPage womenPage = new WomenPage(driver);
        womenPage.selectJacketsCategory();

        // Step 2: Filter by color (e.g., Blue)
        womenPage.filterByColor("blue");

        // Step 3: Verify all displayed products have the selected color
        Assert.assertTrue(womenPage.areAllProductsFilteredByColor("blue"), "Not all products are filtered by the selected color!");

        // Step 4: Filter by price range ($50.00 - $59.99)
        womenPage.filterByPriceRange();

        // Step 5: Verify only two products are displayed
        Assert.assertEquals(womenPage.getNumberOfProducts(), 2, "Incorrect number of products!");

        // Step 6: Verify the price of each product matches the criteria
        Assert.assertTrue(womenPage.areAllProductsInPriceRange(50.00, 59.99), "Not all products are within the selected price range!");
    }
}
