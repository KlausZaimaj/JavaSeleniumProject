package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;
import pages.ShoppingCartPage;
import pages.WomenPage;
import utils.WebDriverSetup;

public class EmptyShoppingCartTest extends WebDriverSetup {

    @Test
    public void testEmptyShoppingCart() {
        // Precondition: Add items to the shopping cart (use ShoppingCartTest logic)
        driver.get("https://magento.softwaretestingboard.com/");
        HomePage homePage = new HomePage(driver);
        homePage.clickSignIn();
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("johnny.smith@gmail.com", "Password123!");
        homePage.clickWomenMenu();
        WomenPage womenPage = new WomenPage(driver);
        womenPage.selectJacketsCategory();
        ShoppingCartPage shoppingCartPage = new ShoppingCartPage(driver);
        shoppingCartPage.addAllItemsToCart();
        shoppingCartPage.navigateToCart();

        // Step 1: Delete the first item
        shoppingCartPage.deleteAllItemsFromCart();

        // Step 2: Verify the number of items decreases
        Assert.assertTrue(shoppingCartPage.isCartEmpty(), "Shopping cart is not empty!");

        // Step 3: Repeat until all items are deleted
        // (Handled in deleteAllItemsFromCart method)

        // Step 4: Verify the shopping cart is empty
        Assert.assertTrue(shoppingCartPage.isCartEmpty(), "Shopping cart is not empty!");

        // Step 5: Close the browser
        driver.quit();
    }
}
