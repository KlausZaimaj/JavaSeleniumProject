package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;
import utils.WebDriverSetup;

public class SignInTest extends WebDriverSetup {

    @Test
    public void testSignIn() {
        // Step 1: Navigate to the homepage
        driver.get("https://magento.softwaretestingboard.com/");
        HomePage homePage = new HomePage(driver);

        // Step 2: Click Sign In link
        homePage.clickSignIn();

        // Step 3: Log in with credentials from Test 1
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("johnny.smith@gmail.com", "Password123!");

        // Step 4: Verify the username is displayed
        Assert.assertTrue(loginPage.isWelcomeMessageDisplayed(), "Login failed!");

        // Step 5: Sign out
        loginPage.signOut();
    }
}
