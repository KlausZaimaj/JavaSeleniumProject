package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;
import pages.ShoppingCartPage;
import pages.WomenPage;
import utils.WebDriverSetup;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.List;
import java.util.Locale;

public class ShoppingCartTest extends WebDriverSetup {

    @Test
    public void testShoppingCart() {
        // Precondition: Sign in and navigate to Women > Tops > Jackets
        driver.get("https://magento.softwaretestingboard.com/");
        HomePage homePage = new HomePage(driver);
        homePage.clickSignIn();
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("johnny.smith@gmail.com", "Password123!");
        homePage.clickWomenMenu();
        WomenPage womenPage = new WomenPage(driver);
        womenPage.selectJacketsCategory();

        // Step 1: Add all displayed items to the shopping cart
        ShoppingCartPage shoppingCartPage = new ShoppingCartPage(driver);
        shoppingCartPage.addAllItemsToCart();

        // Step 2: Verify the success message
        Assert.assertTrue(shoppingCartPage.isSuccessMessageDisplayed(), "Items not added to cart!");

        // Step 3: Open the shopping cart
        shoppingCartPage.navigateToCart();

        // Step 4: Verify navigation to the shopping cart page
        Assert.assertEquals(driver.getTitle(), "Shopping Cart");

        // Step 5: Verify the total price matches the sum of item prices
        verifyTotalPriceMatchesSumOfItems(shoppingCartPage);
    }

    private void verifyTotalPriceMatchesSumOfItems(ShoppingCartPage shoppingCartPage) {
        // Get the list of item prices
        List<Double> itemPrices = shoppingCartPage.getItemPrices();

        // Calculate the sum of item prices
        double sumOfItemPrices = itemPrices.stream().mapToDouble(Double::doubleValue).sum();

        // Get the Order Total price from the Summary section
        double orderTotalPrice = shoppingCartPage.getOrderTotalPrice();

        // Compare the sum of item prices with the Order Total price
        Assert.assertEquals(sumOfItemPrices, orderTotalPrice, 0.01, "Total price does not match the sum of item prices!");
    }
}