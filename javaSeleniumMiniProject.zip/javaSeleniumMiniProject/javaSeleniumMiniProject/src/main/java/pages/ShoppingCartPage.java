package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.time.Duration;

public class ShoppingCartPage {
    WebDriver driver;

    @FindBy(css = ".cart.item")
    List<WebElement> cartItems;

    @FindBy(css = ".price")
    List<WebElement> itemPrices;

    @FindBy(css = ".totals .grand .price")
    WebElement orderTotalPrice;

    @FindBy(css = ".action.delete")
    List<WebElement> deleteButtons;

    @FindBy(css = ".cart-empty")
    WebElement emptyCartMessage;

    public ShoppingCartPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void addAllItemsToCart() {
        // Logic to add items to the cart (already implemented)
    }

    public boolean isSuccessMessageDisplayed() {
        // Logic to check success message (already implemented)
        return true;
    }

    public void navigateToCart() {
        // Logic to navigate to the shopping cart (already implemented)
    }

    /**
     * Extracts the prices of all items in the shopping cart.
     *
     * @return List of item prices as doubles.
     */
    public List<Double> getItemPrices() {
        List<Double> prices = new ArrayList<>();
        for (WebElement priceElement : itemPrices) {
            String priceText = priceElement.getText().replace("$", "").replace(",", "");
            try {
                double price = NumberFormat.getNumberInstance(Locale.US).parse(priceText).doubleValue();
                prices.add(price);
            } catch (ParseException e) {
                throw new RuntimeException("Failed to parse price: " + priceText, e);
            }
        }
        return prices;
    }

    /**
     * Extracts the Order Total price from the Summary section.
     *
     * @return Order Total price as a double.
     */
    public double getOrderTotalPrice() {
        String totalPriceText = orderTotalPrice.getText().replace("$", "").replace(",", "");
        try {
            return NumberFormat.getNumberInstance(Locale.US).parse(totalPriceText).doubleValue();
        } catch (ParseException e) {
            throw new RuntimeException("Failed to parse Order Total price: " + totalPriceText, e);
        }
    }

    /**
     * Deletes all items from the shopping cart.
     */
    public void deleteAllItemsFromCart() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        while (!cartItems.isEmpty()) {
            wait.until(ExpectedConditions.elementToBeClickable(deleteButtons.get(0))).click();
            wait.until(ExpectedConditions.stalenessOf(cartItems.get(0)));
            PageFactory.initElements(driver, this); // Re-initialize elements
        }
    }

    /**
     * Checks if the shopping cart is empty.
     *
     * @return True if the cart is empty, false otherwise.
     */
    public boolean isCartEmpty() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        return wait.until(ExpectedConditions.visibilityOf(emptyCartMessage)).isDisplayed();
    }
}
