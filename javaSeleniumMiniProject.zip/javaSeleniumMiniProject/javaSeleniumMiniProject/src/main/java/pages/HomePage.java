package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
    WebDriver driver;

    @FindBy(linkText = "Create an Account")
    WebElement createAccountLink;

    @FindBy(linkText = "Sign In")
    WebElement signInLink;

    @FindBy(linkText = "Women")
    WebElement womenMenu;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void clickCreateAccount() {
        createAccountLink.click();
    }

    public void clickSignIn() {
        signInLink.click();
    }

    public void clickWomenMenu() {
        womenMenu.click();
    }
}