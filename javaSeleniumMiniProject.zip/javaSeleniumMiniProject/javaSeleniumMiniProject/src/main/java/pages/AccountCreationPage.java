package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class AccountCreationPage {
    WebDriver driver;
    WebDriverWait wait;

    @FindBy(id = "firstname")
    WebElement firstNameField;

    @FindBy(id = "lastname")
    WebElement lastNameField;

    @FindBy(id = "email_address")
    WebElement emailField;

    @FindBy(id = "password")
    WebElement passwordField;

    @FindBy(id = "password-confirmation")
    WebElement confirmPasswordField;

    @FindBy(css = "button[title='Create an Account']")
    WebElement createAccountButton;

    @FindBy(css = ".message-success")
    WebElement successMessage;

    @FindBy(css = ".action.switch")
    WebElement userProfileDropdown;

    @FindBy(linkText = "Sign Out")
    WebElement signOutLink;

    public AccountCreationPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Wait up to 10 seconds
        PageFactory.initElements(driver, this);
    }

    public void fillForm(String firstName, String lastName, String email, String password) {
        firstNameField.sendKeys(firstName);
        lastNameField.sendKeys(lastName);
        emailField.sendKeys(email);
        passwordField.sendKeys(password);
        confirmPasswordField.sendKeys(password);
    }

    public void clickCreateAccountButton() {
        createAccountButton.click();
    }

    public boolean isSuccessMessageDisplayed() {
        try {
            // Wait for the success message to be visible
            wait.until(ExpectedConditions.visibilityOf(successMessage));
            return successMessage.isDisplayed();
        } catch (Exception e) {
            return false; // Return false if the element is not found within the timeout
        }
    }

    public void signOut() {
        userProfileDropdown.click();
        signOutLink.click();
    }
}