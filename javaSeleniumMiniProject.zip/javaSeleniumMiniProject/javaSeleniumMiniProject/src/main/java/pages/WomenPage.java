package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class WomenPage {
    private WebDriver driver;

    @FindBy(css = ".categories-menu .item:nth-child(2) > a")
    private WebElement topsCategory;

    @FindBy(css = ".categories-menu .item:nth-child(2) .item:nth-child(1) > a")
    private WebElement jacketsSubCategory;

    @FindBy(xpath = "//*[contains(text(), 'Color')]")
    private WebElement colorFilter;

    @FindBy(css = ".swatch-option.color[option-label='Blue']")
    private WebElement blueColorOption;

    @FindBy(css = ".swatch-option.color[option-label='Red']")
    private WebElement redColorOption;

    @FindBy(css = ".product-item")
    private List<WebElement> productItems;

    @FindBy(xpath = "//*[contains(text(), 'Price')]")
    private WebElement priceFilter;

    @FindBy(xpath = "//*[contains(text(), '$50.00 - $59.99')]")
    private WebElement priceRangeOption;

    @FindBy(css = ".filter-current")
    private WebElement currentFilters;

    @FindBy(css = ".filter-current .action.remove")
    private WebElement removeFilterButton;

    public WomenPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void selectJacketsCategory() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));
        wait.until(ExpectedConditions.elementToBeClickable(topsCategory)).click();
        wait.until(ExpectedConditions.elementToBeClickable(jacketsSubCategory)).click();
    }

    public void filterByColor(String color) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));
        wait.until(ExpectedConditions.elementToBeClickable(colorFilter)).click();
        if (color.equalsIgnoreCase("blue")) {
            wait.until(ExpectedConditions.elementToBeClickable(blueColorOption)).click();
        } else if (color.equalsIgnoreCase("red")) {
            wait.until(ExpectedConditions.elementToBeClickable(redColorOption)).click();
        } else {
            throw new IllegalArgumentException("Unsupported color: " + color);
        }
    }

    public void filterByPriceRange() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));
        wait.until(ExpectedConditions.elementToBeClickable(priceFilter)).click();
        wait.until(ExpectedConditions.elementToBeClickable(priceRangeOption)).click();
    }

    public int getNumberOfProducts() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));
        wait.until(ExpectedConditions.visibilityOfAllElements(productItems));
        return productItems.size();
    }

    public boolean areAllProductsFilteredByColor(String color) {
        for (WebElement product : productItems) {
            WebElement colorElement = product.findElement(By.cssSelector(String.format(".swatch-option.color[option-label='%s']", color)));
            if (!colorElement.isDisplayed()) {
                return false;
            }
        }
        return true;
    }

    public boolean areAllProductsInPriceRange(double minPrice, double maxPrice) {
        for (WebElement product : productItems) {
            WebElement priceElement = product.findElement(By.cssSelector(".price"));
            String priceText = priceElement.getText().replaceAll("[^0-9.]", "");
            double price = Double.parseDouble(priceText);
            if (price < minPrice || price > maxPrice) {
                return false;
            }
        }
        return true;
    }

    public void removePriceFilter() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        if (currentFilters.isDisplayed()) {
            wait.until(ExpectedConditions.elementToBeClickable(removeFilterButton)).click();
        }
    }
}
