package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class WishListPage {
    private WebDriver driver;

    @FindBy(css = ".product-item:nth-child(1) .action.towishlist")
    private WebElement firstItemAddToWishListButton;

    @FindBy(css = ".product-item:nth-child(2) .action.towishlist")
    private WebElement secondItemAddToWishListButton;

    @FindBy(css = ".message-success")
    private WebElement successMessage;

    @FindBy(css = ".block-wishlist .product-item")
    private List<WebElement> wishListItems;

    @FindBy(css = ".block-wishlist .action.viewcart")
    private WebElement viewWishListButton;

    public WishListPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void addFirstTwoItemsToWishList() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(firstItemAddToWishListButton)).click();
        wait.until(ExpectedConditions.elementToBeClickable(secondItemAddToWishListButton)).click();
    }

    public boolean isSuccessMessageDisplayed() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        return wait.until(ExpectedConditions.visibilityOf(successMessage)).isDisplayed();
    }

    public void navigateToWishList() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(viewWishListButton)).click();
    }

    public int getNumberOfWishListItems() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfAllElements(wishListItems));
        return wishListItems.size();
    }
}
