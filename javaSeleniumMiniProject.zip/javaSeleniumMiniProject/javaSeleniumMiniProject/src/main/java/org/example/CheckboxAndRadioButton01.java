package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.*;

import java.util.List;

public class CheckboxAndRadioButton01 {

    public static void main(String[] args) throws Throwable {

        // declaration and instantiation of objects/variables
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.manage().window().maximize();

        driver.get("http://demo.guru99.com/test/radio.html");
//        WebElement radio1 = driver.findElement(By.id("vfb-7-1"));
//        WebElement radio2 = driver.findElement(By.id("vfb-7-2"));
//        WebElement radio3 = driver.findElement(By.id("vfb-7-3"));
//
//        Thread.sleep(5000);
//
//        //Radio Button1 is selected
//        radio1.click();
//
//        if (radio1.isSelected()) {
//            System.out.println("Radio Button Option 1 Selected");
//        }
//        Thread.sleep(2000);
//
//        //Radio Button1 is de-selected and Radio Button2 is selected
//        radio2.click();
//        if (radio2.isSelected()) {
//            System.out.println("Radio Button Option 2 Selected");
//        }
//        Thread.sleep(2000);
//
//        //Radio Button2 is de-selected and Radio Button3 is selected
//        radio3.click();
//        if (radio3.isSelected()) {
//            System.out.println("Radio Button Option 3 Selected");
//        }
//        Thread.sleep(2000);
//
////        // Selecting CheckBox
//        WebElement checkbox1 = driver.findElement(By.id("vfb-6-0"));
//
//        // This will Toggle the Checkbox
//        checkbox1.click();
//        Thread.sleep(2000);


//        // Check whether the Checkbox is toggled on
        List<WebElement> allCheckboxOptions = driver.findElements(By.xpath("//input[@type = 'checkbox']"));

        for (int i = 0; i < allCheckboxOptions.size(); i++) {
            if (allCheckboxOptions.get(i).isSelected()) {
                System.out.println("Checkbox " + (i + 1) + " is selected");
            } else {
                System.out.println("Checkbox " + (i + 1) + " is not selected");
            }
        }


        //Selecting Checkbox and using isSelected Method
        driver.get("http://demo.guru99.com/test/facebook.html");
        Thread.sleep(2000);
        WebElement chkFBPersist = driver.findElement(By.id("persist_box"));
        for (int i = 0; i < 2; i++) {
            chkFBPersist.click();
            Thread.sleep(2000);
            System.out.println("Facebook Persists Checkbox Status is -  " + chkFBPersist.isSelected());
        }
        driver.quit();

    }
}
