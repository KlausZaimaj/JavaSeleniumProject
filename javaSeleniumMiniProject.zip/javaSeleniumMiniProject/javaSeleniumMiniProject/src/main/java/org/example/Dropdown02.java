package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.By;

import java.util.List;

public class Dropdown02 {
    public static void main(String[] args) throws Throwable {
        // declaration and instantiation of objects/variables
        WebDriverManager.chromedriver().setup();

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
//
//        String baseURL = "http://demo.guru99.com/test/newtours/register.php";
//        driver.get(baseURL);
//
//        Select drpCountry = new Select(driver.findElement(By.name("country")));
//
//        JavascriptExecutor jsx = (JavascriptExecutor) driver;
//        jsx.executeScript("arguments[0].scrollIntoView(true);", drpCountry);
//
//        drpCountry.selectByVisibleText("ALBANIA");
//        Thread.sleep(2000);
//
//        drpCountry.selectByValue("AUSTRIA");
//        Thread.sleep(2000);
//
//        drpCountry.selectByIndex(10);
//        Thread.sleep(2000);
//
//        //Print all options
//        System.out.println("All country options are:");
//        List<WebElement> allOptions = drpCountry.getOptions();
//
//        for (WebElement option : allOptions
//        ) {
//            System.out.println(option.getText());
//        }

//
//        //Selecting Items in a Multiple SELECT elements
        driver.get("http://jsbin.com/osebed/2");
        Select fruits = new Select(driver.findElement(By.id("fruits")));

        if (fruits.isMultiple()) {
            System.out.println("Fruits dropdown is multiple.");
        }

        fruits.selectByVisibleText("Banana");
        Thread.sleep(2000);
        fruits.selectByIndex(1);
        Thread.sleep(2000);
        fruits.selectByValue("orange");
        Thread.sleep(2000);

//        //Print all selected options
        System.out.println("1. Selected option on fruits dropdown are:");
        List<WebElement> allSelectedOptions = fruits.getAllSelectedOptions();
        for (WebElement selectedOption : allSelectedOptions
        ) {
            System.out.println(selectedOption.getText());
        }
//
        //Deselecting items in dropdown
        fruits.deselectByValue("banana");
        Thread.sleep(2000);
        fruits.deselectByIndex(2);
        Thread.sleep(2000);
        fruits.deselectByVisibleText("Apple");
        Thread.sleep(2000);

        //Print all selected options
        System.out.println("2. Selected option on fruits dropdown are:");
        allSelectedOptions = fruits.getAllSelectedOptions();
        for (WebElement selectedOption : allSelectedOptions
        ) {
            System.out.println(selectedOption.getText());
        }

        fruits.deselectAll();

        System.out.println("3. Selected option on fruits dropdown are:");
        allSelectedOptions = fruits.getAllSelectedOptions();
        for (WebElement selectedOption : allSelectedOptions
        ) {
            System.out.println(selectedOption.getText());
        }

        driver.close();
    }
}

