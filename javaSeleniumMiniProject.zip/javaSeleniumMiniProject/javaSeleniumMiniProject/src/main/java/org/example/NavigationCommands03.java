package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class NavigationCommands03 {

    public static void main(String[] args) throws Throwable {

        //Chrome Browser
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.manage().window().maximize();

        String baseUrl = "https://demoqa.com";

        //Launch the WebSite
        driver.get(baseUrl);

        Thread.sleep(4000);

//        WebElement consentButton = driver.findElement(By.xpath("//button[@aria-label='Consent']"));
//        consentButton.click();


        /* to(String arg0) : void – This method Loads a new web page in the current browser window.
         * It accepts a String parameter and returns nothing.
         */
        driver.navigate().to("https://www.selenium.dev/");
        Thread.sleep(3000);


        /* back() : void – This method does the same operation as clicking on the Back Button of any browser.
         * It neither accepts nor returns anything.
         */
        driver.navigate().back();
        Thread.sleep(3000);

        /* forward() : void – This method does the same operation as clicking on the Forward Button of any browser.
         * It neither accepts nor returns anything.
         */
        driver.navigate().forward();
        Thread.sleep(3000);


        /* refresh() : void – This method Refresh the current page.
         * It neither accepts nor returns anything.
         */
        driver.navigate().refresh();
        Thread.sleep(3000);


//        driver.close();
    }
}
