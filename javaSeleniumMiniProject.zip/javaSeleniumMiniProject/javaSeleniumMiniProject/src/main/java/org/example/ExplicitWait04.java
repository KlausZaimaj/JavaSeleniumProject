package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;


public class ExplicitWait04 {

    public static void main(String[] args) throws Throwable {

        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

        String eTitle = "Demo Guru99 Page";
        String aTitle = "";

        // launch Chrome and redirect it to the Base URL
        driver.get("http://demo.guru99.com/test/guru99home/");

        //Maximizes the browser window
        driver.manage().window().maximize();

        //get the actual value of the title
        aTitle = driver.getTitle();

        //compare the actual title with the expected title
        if (aTitle.contentEquals(eTitle)) {
            System.out.println("Test Passed");
        } else {
            System.out.println("Test Failed");
        }

        WebElement guru99Seleniumlink;

        guru99Seleniumlink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#navbar-brand-centered > ul > li:nth-child(1) > a")));
        guru99Seleniumlink.click();

        WebElement radioButtonLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@href, 'radio')]")));
        radioButtonLink.click();

        Thread.sleep(5000);

        driver.close();
    }

}
