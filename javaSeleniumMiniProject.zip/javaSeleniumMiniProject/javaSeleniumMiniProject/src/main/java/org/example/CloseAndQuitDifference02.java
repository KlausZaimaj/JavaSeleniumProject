package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CloseAndQuitDifference02 {

    /*
      1. Launch a new Chrome browser.
      2. Open ToolsQA Practice Automation Page for Switch Windows: https://demoqa.com/browser-windows
      3. Click on a New Browser Window button
      4. Close the browser using close() command
     */

    public static void main(String[] args) throws Throwable {

        //Chrome Browser
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.manage().window().maximize();

        String baseUrl = "https://demoqa.com/browser-windows";

        //Launch the ToolsQA WebSite
        driver.get(baseUrl);

        Thread.sleep(7000);


        WebElement newBrowserWindowButton = driver.findElement(By.id("windowButton"));

        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, arguments[0]);", 100);

        //Click on New Browser Window button
        newBrowserWindowButton.click();

        //Close the window
        //driver.close();
        Thread.sleep(4000);

        //Quit the browser
      //  driver.quit();
    }
}
